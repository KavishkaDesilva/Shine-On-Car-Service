import React from 'react';

const Department = () => {
  return (
    <>
      <div className='py-2 border-bottom border-secondary'>
        <div className='container'>
          <h1 className='text-center'>Department</h1>
        </div>
      </div>
      <div className='container mt-5'>
        <h2>Content goes here</h2>
      </div>
    </>
  );
};

export default Department;
